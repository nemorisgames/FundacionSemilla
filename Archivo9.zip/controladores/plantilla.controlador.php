<?php

Class ControladorPlantilla{

	/*=============================================
	Llamada a la plantilla
	=============================================*/

	public function ctrTraerPlantilla(){

		
		include "vistas/plantilla.php";

	}

}