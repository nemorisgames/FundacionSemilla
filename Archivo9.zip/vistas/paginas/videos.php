<body class="bg4 tam3">

<a href="index.php?pagina=inicio&npag=1"><div class="retornoblog"></div></a>
                    <div class="container-fluid contenedor-vid" style="margin-top :400px">


                        <div class="d-flex justify-content-center menu-st">

                                <div class="card justify-content-center border-0 card-us " style="width: 6rem; border-radius: 2em ">
                                <a href="?pagina=videos">    <h6 class="text-center Nick_Name videos-title-menu">Videos</h6></a>
                                        <div class="progress ml-2 mr-2  menu_progress  ">
                                            <div class="progress-bar " role="progressbar " style="width:25%; background-color: rgb(200, 154, 55);" aria-valuenow="100 " aria-valuemin="0 " aria-valuemax="100 "></div>
                                        </div>
                                        <p class="text-centert porcentaje-tv">25%  </p>
                                </div>

                                <div class="card justify-content-center border-0 card-us " style="width: 6rem; border-radius: 2em ; margin-left:130px;">
                                <a href="?pagina=desafio">           <h6 class="text-center Nick_Name" style="color: rgb(206, 206, 206);">Desafios</h6></a>
                                        <div class="progress ml-2 mr-2  menu_progress  ">
                                            <div class="progress-bar" role="progressbar " style="width:25%;background-color: rgb(206, 206, 206);" aria-valuenow="100 " aria-valuemin="0 " aria-valuemax="100 "></div>
                                        </div>
                                        <p class="text-centert porcentaje-tv"style="color: rgb(206, 206, 206);">25%  </p>
                                </div>

                                <div class="card justify-content-center border-0 card-us " style="width: 6rem; border-radius: 2em ; margin-left:130px;">
                                            <h6 class="text-center Nick_Name" style="color: rgb(206, 206, 206);">Juegos</h6>
                                        <div class="progress ml-2 mr-2  menu_progress  ">
                                            <div class="progress-bar  " role="progressbar " style="width:25%;background-color: rgb(206, 206, 206);" aria-valuenow="100 " aria-valuemin="0 " aria-valuemax="100 "></div>
                                        </div>
                                        <p class="text-centert porcentaje-tv"style="color: rgb(206, 206, 206);">25%  </p>
                                </div>

                                <div class="card justify-content-center border-0 card-us " style="width: 6rem; border-radius: 2em ; margin-left:130px;">
                                <a href="?pagina=blog">  <h6 class="text-center Nick_Name" style="color: rgb(206, 206, 206);">Blog</h6></a>
                                        <div class="progress ml-2 mr-2  menu_progress  ">
                                            <div class="progress-bar  " role="progressbar " style="width:25%;background-color: rgb(206, 206, 206);" aria-valuenow="100 " aria-valuemin="0 " aria-valuemax="100 "></div>
                                        </div>
                                        <p class="text-centert porcentaje-tv"style="color: rgb(206, 206, 206);">25%  </p>
                                </div>

                        </div>

                    </div>

       <div class="container text-center border cont-vidt  ">
            

                 <p class="mt-4 ml-4 Cofre_1" style="margin-righ:-40px;text-align: initial !important;"></p>

                   <div class="d-flex flex-column justify-content-start video-inter" >

                        <div class="d-flex  bd-highlight mt-5  Actividad-titulo">
                            <p>Actividad</p>
                        </div>

                        <div class="d-flex flex-column  Actividad-titulo-text">
                            <p>Con el objetivo de ofrecer una experiencia lo más fiel posible a la realidad, ‘Dirt Rally 2.0’ aboga por los daños reales en los vehículos, así como unas físicas tremendamente exigentes. Una curva mal dada y veremos consecuencias en la chapa, las ruedas o el motor. Un mal volantazo y veremos cómo nuestro automóvil queda totalmente inservible. Y sí, es posible recibir daños letales si lo habilitamos en opciones.</p>
                        </div>
                        
                    </div>

            </div>




                    <div class="container justify-content-start d-flex flex-row border cont-vid1  ">
                            
                            <div class="d-flex flex-row bd-highlight  " style="width: 8rem; border-radius: 2em;position: relative; left: 0; top: 0;">
                                <img class="encima-video1 rounded-circle" src="../../../vistas/img/icon/estrella_check.png">
                            </diV>

                        <div class="mt-4 d-flex flex-column numconte justify-content-start" >
                                <p class="num-vid circulo-vid ">1</p>
                                <p class="tt-video">Microsoft Edge</p>
                                <p class="ttt-video">Análisis: el camino a la cima de la gama media está lleno de curvas.</p>
                                
                        </div>

                        <div class="d-flex justify-content-start contenido-vid-der" >

                        <iframe width="702" height="400" src="https://www.youtube.com/embed/r2kBf8EiAAQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                
                            </div>

                    </div>


                    <div class="container justify-content-start d-flex flex-row border cont-vid1  ">
                            
                            <div class="d-flex flex-row bd-highlight  " style="width: 8rem; border-radius: 2em;position: relative; left: 0; top: 0;">
                                <img class="encima-video1 rounded-circle" src="../../../vistas/img/icon/estrella_check.png">
                            </diV>

                        <div class="mt-4 d-flex flex-column numconte justify-content-start" >
                                <p class="num-vid circulo-vid ">1</p>
                                <p class="tt-video">Microsoft Edge</p>
                                <p class="ttt-video">Análisis: el camino a la cima de la gama media está lleno de curvas.</p>
                                
                        </div>

                        <div class="d-flex justify-content-start contenido-vid-der" >

                        <iframe width="702" height="400" src="https://www.youtube.com/embed/RY47DjD-jbU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                
                            </div>

                    </div>

                    <div class="container justify-content-start d-flex flex-row border cont-vid1  ">
                            
                            <div class="d-flex flex-row bd-highlight  " style="width: 8rem; border-radius: 2em;position: relative; left: 0; top: 0;">
                                <img class="encima-video1 rounded-circle" src="../../../vistas/img/icon/estrella_check.png">
                            </diV>

                        <div class="mt-4 d-flex flex-column numconte justify-content-start" >
                                <p class="num-vid circulo-vid ">1</p>
                                <p class="tt-video">Microsoft Edge</p>
                                <p class="ttt-video">Análisis: el camino a la cima de la gama media está lleno de curvas.</p>
                                
                        </div>

                        <div class="d-flex justify-content-start contenido-vid-der" >

                        <iframe width="702" height="400" src="https://www.youtube.com/embed/nXyT_niBByU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                
                            </div>

                    </div>



</div>

</body>